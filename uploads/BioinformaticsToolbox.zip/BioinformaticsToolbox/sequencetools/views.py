import json

from django.http import HttpResponse
from django.http.response import HttpResponseRedirectBase, JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_protect
from fastapi import requests

from sequencetools.models import SequenceSubmission, ORF
from sequencetools.repo import SubmissionRepository
from sequencetools.utils import handle_file_upload
import requests


# Create your views here.
def index(request):
    return render(request, "base.html", {"message": "Hello, Habibi. willkommen zu meiner Webseite!"})


def submissions(request):
    return render(request, "submissions.html", context={"submissions": SubmissionRepository().get_all_submissions()})


def submit(request):
    if request.method == "POST":
        if is_a_DNA_Sequence(request.POST["text_input"]):
            text_input = request.POST["text_input"]
            file_upload = request.FILES["file_upload"]

            print(text_input)
            print(file_upload)

            newSequenceSubmission = SequenceSubmission(
                text_input=text_input,
                file_upload=file_upload.name,
            )
            newSequenceSubmission.save()

            handle_file_upload(file_upload, file_upload)
            return render(request, "submit.html", context={"info": "Data received"})

        return render(request, "submit.html", context={"info": "Only DNA sequence is allowed"})

    return render(request, "submit.html", context={"info": ""})


def is_a_DNA_Sequence(sequence):
    valid_characters = {'A', 'T', 'C', 'G'}
    sequence = sequence.upper()
    for char in sequence:
        if char not in valid_characters:
            return False
    return True


@csrf_protect
def ORF_FINDER(request):
    if request.method == "POST":
        dna_sequence: str = str(request.POST["dna_sequence"].replace("\n", "").replace("\r", ""))

        if dna_sequence == "":
            return render(request, "ORF_FINDER.html", context={"info": "Füllen Sie bitte das Formular aus"})
        # ich hasse alles was da steht
        if is_a_DNA_Sequence(dna_sequence):
            min_orf_length = int(request.POST["min_orf_length"])
            both_strands = request.POST.get("both-strands") == "on"
            try:
                # der hat mein Laptop zum Zucken gebracht, als wäre es auf Entzug
                respond = requests.post("http://127.0.0.1:8081/orf-search/", data=json.dumps(ORF(dna_sequence, min_orf_length, both_strands).__dict__))
                respond.raise_for_status()
                return JsonResponse(respond.json())
            except requests.exceptions.HTTPError as err:
                return render(request, "ORF_FINDER.html", context={"info": f"Fehler: {err}"})
            except Exception as e:
                return render(request, "ORF_FINDER.html",
                              context={"info": f"Ein unerwarteter Fehler ist aufgetreten: {e}"})
        else:
            return render(request, "ORF_FINDER.html", context={"info": "Das ist keine DNA-Sequenz"})

    return render(request, "ORF_FINDER.html")
