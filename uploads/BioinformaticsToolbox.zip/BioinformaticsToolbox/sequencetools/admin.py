from django.contrib import admin
from .models import SequenceSubmission
# Register your models here.
admin.site.register(SequenceSubmission)
